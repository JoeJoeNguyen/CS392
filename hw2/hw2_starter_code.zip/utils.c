#include "utils.h"


/*
	You are free to use any data type you like in this file.
    However, other than the five functions declared in "utils.h",
    DO NOT create any other functions.
	
*/

int cmpr_int(void*, void*) {
	
	/* Your code here */
}

int cmpr_double(void*,void*) {
	
	/* Your code here */
}

void print_int(void*) {
	
	/* Your code here */
}

void print_double(void*) {
	
	/* Your code here */
}


void* read_array(char* filename, char* format, size_t* len) {
	
	/* Your code here */
}