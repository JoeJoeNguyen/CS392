
#include <stdio.h>
#include <stdlib.h>

/*
	DO NOT change this file.
*/

void bubble_sort(void*, size_t, size_t, int (*)(void*,void*));
void bubble_print(void*, size_t, size_t, void (*)(void*));