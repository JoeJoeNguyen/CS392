
#include <stdio.h>

/*
	DO NOT change this file.
*/

int   cmpr_int(void*, void*);
int   cmpr_double(void*,void*);
void  print_int(void*);
void  print_double(void*);
void* read_array(char* filename, char* format, size_t* len);