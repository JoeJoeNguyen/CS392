#!/bin/bash
# here.sh

cat << EOF
The current working directory is: $(pwd)
You are logged in as: $(whoami)
EOF
