#!/bin/bash
# pipe1.sh

cat << EOF | sort
Terry Jones
Susan Gee
Linda Gray
Leslie Smith
Leonard Schmidt
Jenny Case
Dana David
Colin Doe
Bob Jones
EOF
