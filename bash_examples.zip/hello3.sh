#!/bin/bash
# hello3.sh

readonly STR="Hello World!"
echo $STR
STR="Changed my mind!"
echo $STR
